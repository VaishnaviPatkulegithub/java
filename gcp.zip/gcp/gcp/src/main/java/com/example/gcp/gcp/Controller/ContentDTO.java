package com.example.gcp.gcp.Controller;

public record ContentDTO (String content){

}
