package com.example.testUtility;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TestUtilityApplication {

	public static void main(String[] args) {
		SpringApplication.run(TestUtilityApplication.class, args);
	}

}
