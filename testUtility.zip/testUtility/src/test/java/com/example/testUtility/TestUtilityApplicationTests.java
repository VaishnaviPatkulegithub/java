package com.example.testUtility;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TestUtilityApplicationTests {

	@Test
	void contextLoads() {
	}

}
