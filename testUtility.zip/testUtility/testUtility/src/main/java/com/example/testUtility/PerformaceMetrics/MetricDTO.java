package com.example.testUtility.PerformaceMetrics;

import java.time.LocalDateTime;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


@AllArgsConstructor
@NoArgsConstructor
public class MetricDTO {

	private String testRunId;
    private String metricName;
    private Double metricValue;
    private LocalDateTime timestamp;
	public String getTestRunId() {
		return testRunId;
	}
	public void setTestRunId(String testRunId) {
		this.testRunId = testRunId;
	}
	public String getMetricName() {
		return metricName;
	}
	public void setMetricName(String metricName) {
		this.metricName = metricName;
	}
	public Double getMetricValue() {
		return metricValue;
	}
	public void setMetricValue(Double metricValue) {
		this.metricValue = metricValue;
	}
	public LocalDateTime getTimestamp() {
		return timestamp;
	}
	public void setTimestamp(LocalDateTime timestamp) {
		this.timestamp = timestamp;
	}
	public MetricDTO(String testRunId, String metricName, Double metricValue, LocalDateTime timestamp) {
		super();
		this.testRunId = testRunId;
		this.metricName = metricName;
		this.metricValue = metricValue;
		this.timestamp = timestamp;
	}
    
	
    
}
