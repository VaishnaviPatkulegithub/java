package com.example.testUtility.PerformaceMetrics;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collector;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class MetricsServices {
	

	@Autowired
	private MetricRepository metricRepo;
	
	@Autowired
	private AnomaliesRepository anomalyRepo;
	

	public void saveMetrics(List<MetricDTO> metrics) {
		metrics.forEach(m->{
			metricRepo.save(new PerformanceMetrics
					(null, m.getTestRunId(), m.getMetricName(), m.getMetricValue(), m.getTimestamp()
							));
		});
	}


	public List<AnomalyDTO> detectAnomalies(String testRunId){
		List<PerformanceMetrics> metrics = metricRepo.findByTestRunId(testRunId);
		
		Map<String, List<Double>> grouped = metrics.stream()
				.collect(Collectors.groupingBy(PerformanceMetrics::getMetricName,
						Collectors.mapping(PerformanceMetrics::getMetricValue, Collectors.toList())
								));
		
		List<AnomalyDTO> anonolies = new ArrayList<>();
		
		for(Map.Entry<String, List<Double>> entry: grouped.entrySet()) {
			String metric = entry.getKey();
			List<Double> values = entry.getValue();
			
			double mean = values.stream().mapToDouble(Double::doubleValue).average().orElse(0.0);
			double variance = values.stream().mapToDouble(v-> Math.pow(v -mean, 2)).average().orElse(0.0);
			double stdDev = Math.sqrt(variance);
			
			  double upperBound = mean + 2 * stdDev;
	            double lowerBound = mean - 2 * stdDev;
	            
	         for(PerformanceMetrics m :metrics) {
	           if(m.getMetricName().equals(metric) && (m.getMetricValue() > upperBound || m.getMetricValue() < lowerBound)) {
	            		
	            		Anomalies anomoly = new Anomalies(null, testRunId, metric, m.getMetricValue(),
	            					"Value out of expected Range [" + lowerBound + "," + upperBound + "]", m.getTimestamp());
	            		
	            		anomalyRepo.save(anomoly);
	            		
	            		anonolies.add(new AnomalyDTO(testRunId, metric, m.getMetricValue(), "Anomoly detected", m.getTimestamp()));
	            		
	            	}
	            }
		}
		return anonolies;
	}


}
