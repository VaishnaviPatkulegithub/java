package com.example.testUtility.PerformaceMetrics;

import java.time.LocalDateTime;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity

@AllArgsConstructor
@NoArgsConstructor
@Builder
public class Anomalies {
	
	 @Id
	    @GeneratedValue(strategy = GenerationType.IDENTITY)
	    private Long id;

	    @Column(name = "test_run_id", nullable = false)
	    private String testRunId;

	    @Column(name = "metric_name", nullable = false)
	    private String metricName;

	    @Column(name = "metric_value", nullable = false)
	    private Double metricValue;

	    @Column(name = "anomaly_reason", nullable = false, length = 255)
	    private String anomalyReason;

	    @Column(name = "timestamp", nullable = false)
	    private LocalDateTime timestamp;

		public Long getId() {
			return id;
		}

		public void setId(Long id) {
			this.id = id;
		}

		public String getTestRunId() {
			return testRunId;
		}

		public void setTestRunId(String testRunId) {
			this.testRunId = testRunId;
		}

		public String getMetricName() {
			return metricName;
		}

		public void setMetricName(String metricName) {
			this.metricName = metricName;
		}

		public Double getMetricValue() {
			return metricValue;
		}

		public void setMetricValue(Double metricValue) {
			this.metricValue = metricValue;
		}

		public String getAnomalyReason() {
			return anomalyReason;
		}

		public void setAnomalyReason(String anomalyReason) {
			this.anomalyReason = anomalyReason;
		}

		public LocalDateTime getTimestamp() {
			return timestamp;
		}

		public void setTimestamp(LocalDateTime timestamp) {
			this.timestamp = timestamp;
		}

		public Anomalies(Long id, String testRunId, String metricName, Double metricValue, String anomalyReason,
				LocalDateTime timestamp) {
			super();
			this.id = id;
			this.testRunId = testRunId;
			this.metricName = metricName;
			this.metricValue = metricValue;
			this.anomalyReason = anomalyReason;
			this.timestamp = timestamp;
		}
	    
	    

}
