package com.example.testUtility.PerformaceMetrics;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class MetricController {
	

    @Autowired
    private MetricsServices metricsService;

    @PostMapping("/upload")
    public ResponseEntity<String> uploadMetrics(@RequestBody List<MetricDTO> metrics) {
        metricsService.saveMetrics(metrics);
        return ResponseEntity.ok("Metrics saved successfully!");
    }

    @GetMapping("/anomalies/{testRunId}")
    public ResponseEntity<List<AnomalyDTO>> getAnomalies(@PathVariable String testRunId) {
        return ResponseEntity.ok(metricsService.detectAnomalies(testRunId));
    }

}
