package com.example.testUtility.PerformaceMetrics;

import java.time.LocalDateTime;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


@AllArgsConstructor
@NoArgsConstructor
public class AnomalyDTO {
	 private String testRunId;
	    private String metricName;
	    private Double metricValue;
	    private String anomalyReason;
	    private LocalDateTime timestamp;
		public String getTestRunId() {
			return testRunId;
		}
		public void setTestRunId(String testRunId) {
			this.testRunId = testRunId;
		}
		public String getMetricName() {
			return metricName;
		}
		public void setMetricName(String metricName) {
			this.metricName = metricName;
		}
		public Double getMetricValue() {
			return metricValue;
		}
		public void setMetricValue(Double metricValue) {
			this.metricValue = metricValue;
		}
		public String getAnomalyReason() {
			return anomalyReason;
		}
		public void setAnomalyReason(String anomalyReason) {
			this.anomalyReason = anomalyReason;
		}
		public LocalDateTime getTimestamp() {
			return timestamp;
		}
		public void setTimestamp(LocalDateTime timestamp) {
			this.timestamp = timestamp;
		}
		public AnomalyDTO(String testRunId, String metricName, Double metricValue, String anomalyReason,
				LocalDateTime timestamp) {
			super();
			this.testRunId = testRunId;
			this.metricName = metricName;
			this.metricValue = metricValue;
			this.anomalyReason = anomalyReason;
			this.timestamp = timestamp;
		}
	
		
	    
}
