package com.example.testUtility.PerformaceMetrics;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface AnomaliesRepository extends JpaRepository<Anomalies, Long>{

}
