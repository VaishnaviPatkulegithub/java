package com.example.crud.Product;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.time.Instant;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Random;

import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

@Service
public class PerformanceService {
	
	public PerformanceReport analyzeJtl(MultipartFile file) throws Exception {
        List<JtlRecord> records = parseJtl(file);

        long total = records.size();
        long failed = records.stream().filter(r -> !r.isSuccess()).count();
        long success = total - failed;

        double avg = records.stream().mapToLong(JtlRecord::getElapsed).average().orElse(0);
        double median = median(records.stream().mapToLong(JtlRecord::getElapsed).toArray());
        double p95 = percentile(records.stream().mapToLong(JtlRecord::getElapsed).toArray(), 95);
        long max = records.stream().mapToLong(JtlRecord::getElapsed).max().orElse(0);

        
        long minTs = records.stream().mapToLong(JtlRecord::getTimestamp).min().orElse(0);
        long maxTs = records.stream().mapToLong(JtlRecord::getTimestamp).max().orElse(1);
        double throughput = total / ((maxTs - minTs) / 1000.0);

        PerformanceReport report = new PerformanceReport();
        report.setTestRunId(new Random().nextInt(1000));
        report.setSummary(new Summary(total, success, failed, (failed * 100.0) / total + "%"));
        report.setPerformance(new Performance(avg, median, p95, max, throughput));

        
        List<Anomaly> anomalies = new ArrayList();
        if (p95 > avg * 2) {
            anomalies.add(new Anomaly(Instant.now().toString(),
                    "Response time spiked by 70% at 10:05 AM", true));
        }
        report.setAnomalies(anomalies);
        report.setStatus("ANALYSIS_COMPLETED");

        return report;
    }

    private List<JtlRecord> parseJtl(MultipartFile file) throws Exception {
        List<JtlRecord> records = new ArrayList<>();
        try (BufferedReader br = new BufferedReader(new InputStreamReader(file.getInputStream()))) {
            String line;
            br.readLine(); 
            while ((line = br.readLine()) != null) {
                String[] parts = line.split(",");
                JtlRecord record = new JtlRecord(
                        Long.parseLong(parts[0]),   
                        Long.parseLong(parts[1]),   
                        Boolean.parseBoolean(parts[7]) 
                );
                records.add(record);
            }
        }
        return records;
    }

    private double percentile(long[] values, double percentile) {
        Arrays.sort(values);
        int index = (int) Math.ceil(percentile / 100.0 * values.length);
        return values[index - 1];
    }

    private double median(long[] values) {
        Arrays.sort(values);
        int n = values.length;
        return n % 2 == 0 ? (values[n/2 - 1] + values[n/2]) / 2.0 : values[n/2];
    }

}
