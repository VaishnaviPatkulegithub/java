package com.example.crud.Product;


import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

@RestController
@RequestMapping("/api/performance")
public class PerformanceController {
	   private final PerformanceService performanceService;
	    private final JMeterLogService logService;
	    private final PerformanceMetrics metrics;
	    private final AnalysisResultRepository analysisResultRepository;

	    public PerformanceController(PerformanceService performanceService,
	                                 JMeterLogService logService,
	                                 PerformanceMetrics metrics,
	                                 AnalysisResultRepository analysisResultRepository) {
	        this.performanceService = performanceService;
	        this.logService = logService;
	        this.metrics = metrics;
	        this.analysisResultRepository = analysisResultRepository;
	    }

//	    @PostMapping(value = "/analyze", consumes = "multipart/form-data")
//	    public ResponseEntity<?> analyzeLog(@RequestParam("file") MultipartFile file) {
//	        try {
//	            PerformanceReport report = performanceService.analyzeJtl(file);
//	            return ResponseEntity.ok(report);
//	        } catch (Exception e) {
//	            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
//	                                 .body(Map.of("error", e.getMessage()));
//	        }
//	    }
	    
//	  @PostMapping("/analyze")
//	  public Map<String, Object> analyzePerformance(@RequestParam("file") MultipartFile file) throws Exception {
//	      List<JMeterResult> results = logService.readResults(file);
//
//	      double avgResponseTime = results.stream().mapToLong(JMeterResult::getElapsed).average().orElse(0);
//	      long errorCount = results.stream().filter(r -> !r.isSuccess()).count();
//	      long totalRequests = results.size();
//	      double errorRate = (totalRequests > 0) ? (errorCount * 100.0 / totalRequests) : 0;
//
//	      Map<String, Double> labelWiseAvg = results.stream()
//	              .collect(Collectors.groupingBy(JMeterResult::getLabel,
//	                      Collectors.averagingLong(JMeterResult::getElapsed)));
//
//	      // ✅ If AnomalyDetector not implemented, comment this line
//	      List<String> anomalies = AnomalyDetector.detectAnomalies(results);
//
//	      // ✅ If metrics bean not ready, comment this too
//	      metrics.recordMetrics(totalRequests, avgResponseTime, errorCount, anomalies.size());
//
//	      Map<String, Object> analysis = new HashMap();
//	      analysis.put("totalRequests", totalRequests);
//	      analysis.put("avgResponseTimeMs", avgResponseTime);
//	      analysis.put("errorCount", errorCount);
//	      analysis.put("errorRatePercent", errorRate);
//	      analysis.put("avgResponseTimePerAPI", labelWiseAvg);
//	      analysis.put("anomalies", anomalies);
//
//	      return analysis;
//	  }
	  

	  @PostMapping(value = "/analyze", consumes = "multipart/form-data")
	  public AnalysisResult analyzePerformance(@RequestParam("file") MultipartFile file) throws Exception {
	  List<JMeterResult> results = logService.readResults(file);


	  long totalRequests = results.size();
	  long successRequests = results.stream().filter(JMeterResult::isSuccess).count();
	  long failedRequests = totalRequests - successRequests;
	  String errorRate = totalRequests > 0 ? String.format("%.1f%%", (failedRequests * 100.0 / totalRequests)) : "0.0%";


	  
	  List<Long> elapsedSorted = results.stream().map(JMeterResult::getElapsed).sorted().toList();


	  double avgResponseTime = elapsedSorted.stream().mapToLong(Long::longValue).average().orElse(0);
	  double medianResponseTime = median(elapsedSorted);
	  double p95ResponseTime = percentile(elapsedSorted, 95);
	  long maxResponseTime = elapsedSorted.isEmpty() ? 0 : elapsedSorted.get(elapsedSorted.size() - 1);


	
	  long startTime = results.stream().mapToLong(JMeterResult::getTimestamp).min().orElse(0);
	  long endTime = results.stream().mapToLong(JMeterResult::getTimestamp).max().orElse(0);
	  double durationSeconds = (endTime - startTime) / 1000.0;
	  double throughputRps = durationSeconds > 0 ? totalRequests / durationSeconds : 0;


	  List<String> anomalies = AnomalyDetector.detectAnomalies(results);


	  // Record into Prometheus gauges
	  metrics.recordMetrics(totalRequests, avgResponseTime, failedRequests, anomalies.size());


	  AnalysisResult analysis = new AnalysisResult(
	  227L, 
	  (int) totalRequests,
	  (int) successRequests,
	  (int) failedRequests,
	  errorRate,
	  round2(avgResponseTime),
	  round2(medianResponseTime),
	  round2(p95ResponseTime),
	  maxResponseTime,
	  round2(throughputRps),
	  anomalies,
	  "ANALYSIS_COMPLETED"
	  );


	  return analysisResultRepository.save(analysis);
	  }
	  


	  private double median(List<Long> sorted) {
	  if (sorted.isEmpty()) return 0;
	  int n = sorted.size();
	  if (n % 2 == 1) return sorted.get(n/2);
	  return (sorted.get(n/2 - 1) + sorted.get(n/2)) / 2.0;
	  }


	  private double percentile(List<Long> sorted, int p) {
	  if (sorted.isEmpty()) return 0;
	  double rank = Math.ceil(p / 100.0 * sorted.size());
	  int idx = (int) Math.min(Math.max(rank - 1, 0), sorted.size() - 1);
	  return sorted.get(idx);
	  }


	  private double round2(double v) {
	  return Math.round(v * 100.0) / 100.0;
	  }
	  }

