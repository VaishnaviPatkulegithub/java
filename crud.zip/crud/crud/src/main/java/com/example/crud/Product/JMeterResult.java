package com.example.crud.Product;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Table;

@Entity
@Table(name = "jmeter_results")
public class JMeterResult {
	
	 @Id
	    @GeneratedValue(strategy = GenerationType.IDENTITY)
	    private Long id;

	 
	    private long elapsed;   
	    private boolean success;
	    private String label;

	    private long timestamp; 

		public Long getId() {
			return id;
		}

		public void setId(Long id) {
			this.id = id;
		}

		public long getElapsed() {
			return elapsed;
		}

		public void setElapsed(long elapsed) {
			this.elapsed = elapsed;
		}

		public boolean isSuccess() {
			return success;
		}

		public void setSuccess(boolean success) {
			this.success = success;
		}

		public String getLabel() {
			return label;
		}

		public void setLabel(String label) {
			this.label = label;
		}

		public long getTimestamp() {
			return timestamp;
		}

		public void setTimestamp(long timestamp) {
			this.timestamp = timestamp;
		}

		public JMeterResult(Long id, long elapsed, boolean success, String label, long timestamp) {
			super();
			this.id = id;
			this.elapsed = elapsed;
			this.success = success;
			this.label = label;
			this.timestamp = timestamp;
		}

		public JMeterResult() {
			super();
			// TODO Auto-generated constructor stub
		}
	    
		
	    
    
    

}
