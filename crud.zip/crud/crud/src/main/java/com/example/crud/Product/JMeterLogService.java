package com.example.crud.Product;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.opencsv.CSVReader;

@Service
public class JMeterLogService {
	
	private final JMeterResultRepository repository;


	public JMeterLogService(JMeterResultRepository repository) {
	this.repository = repository;
	}



	public List<JMeterResult> readResults(MultipartFile file) throws Exception {
	List<JMeterResult> results = new ArrayList<>();


	try (CSVReader reader = new CSVReader(new InputStreamReader(file.getInputStream()))) {
	String[] header = reader.readNext();
	if (header == null) return results;


	Map<String, Integer> idx = indexByName(header);
	String[] row;
	while ((row = reader.readNext()) != null) {
	long timeStamp = parseLong(row, idx.get("timeStamp"));
	long elapsed = parseLong(row, idx.get("elapsed"));
	String label = parseString(row, idx.get("label"));
	boolean success= parseBoolean(row, idx.get("success"));



	JMeterResult r = new JMeterResult();
	r.setElapsed(elapsed);
	r.setSuccess(success);
	r.setLabel(label);
	r.setTimestamp(timeStamp);
	results.add(r);
	}
	}



	repository.saveAll(results);
	return results;
	}


	private Map<String, Integer> indexByName(String[] header) {
	Map<String, Integer> map = new HashMap<String, Integer>();
	for (int i = 0; i < header.length; i++) {
	map.put(header[i], i);
	}
	return map;
	}


	private long parseLong(String[] row, Integer i) {
	if (i == null || i >= row.length) return 0L;
	try { return Long.parseLong(row[i]); } catch (Exception e) { return 0L; }
	}


	private String parseString(String[] row, Integer i) {
	if (i == null || i >= row.length) return null;
	return row[i];
	}


	private boolean parseBoolean(String[] row, Integer i) {
	if (i == null || i >= row.length) return false;
	return Boolean.parseBoolean(row[i]);
	}
	
//	 private final JMeterResultRepository repository;
//
//	    public JMeterLogService(JMeterResultRepository repository) {
//	        this.repository = repository;
//	    }
//
//	    public List<JMeterResult> readResults(MultipartFile file) throws Exception {
//	        List<JMeterResult> results = new ArrayList<>();
//	        try (BufferedReader br = new BufferedReader(new InputStreamReader(file.getInputStream()))) {
//	            String line;
//	            boolean headerSkipped = false;
//
//	            while ((line = br.readLine()) != null) {
//	               
//	                if (!headerSkipped) {
//	                    headerSkipped = true;
//	                    continue;
//	                }
//
//	               
//	                String[] parts = line.split(",");
//	                if (parts.length < 5) continue;
//
//	                String label = parts[2];
//	                long elapsed = Long.parseLong(parts[1]);
//	                boolean success = Boolean.parseBoolean(parts[4]);
//
//	                JMeterResult result = new JMeterResult(label, elapsed, success, times);
//	                results.add(result);
//
//	               
//	                repository.save(result);
//	            }
//	        }
//	        return results;
//	    }
}
