package com.example.crud.Product;

public class Anomaly {
	
	private String timestamp;
    private String details;
    private boolean anomalyDetected;
	
    
    
	public String getTimestamp() {
		return timestamp;
	}
	public void setTimestamp(String timestamp) {
		this.timestamp = timestamp;
	}
	public String getDetails() {
		return details;
	}
	public void setDetails(String details) {
		this.details = details;
	}
	public boolean isAnomalyDetected() {
		return anomalyDetected;
	}
	public void setAnomalyDetected(boolean anomalyDetected) {
		this.anomalyDetected = anomalyDetected;
	}
	
	public Anomaly(String timestamp, String details, boolean anomalyDetected) {
		super();
		this.timestamp = timestamp;
		this.details = details;
		this.anomalyDetected = anomalyDetected;
	}
	public Anomaly() {
		super();
		// TODO Auto-generated constructor stub
	}
    
    

}
