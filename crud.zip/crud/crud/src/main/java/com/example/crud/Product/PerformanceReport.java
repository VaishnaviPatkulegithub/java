package com.example.crud.Product;

import java.util.List;

public class PerformanceReport {

	private long testRunId;
    private Summary summary;
    private Performance performance;
    private List<Anomaly> anomalies;
    private String status;
	public long getTestRunId() {
		return testRunId;
	}
	public void setTestRunId(long testRunId) {
		this.testRunId = testRunId;
	}
	public Summary getSummary() {
		return summary;
	}
	public void setSummary(Summary summary) {
		this.summary = summary;
	}
	public Performance getPerformance() {
		return performance;
	}
	public void setPerformance(Performance performance) {
		this.performance = performance;
	}
	public List<Anomaly> getAnomalies() {
		return anomalies;
	}
	public void setAnomalies(List<Anomaly> anomalies) {
		this.anomalies = anomalies;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public PerformanceReport(long testRunId, Summary summary, Performance performance, List<Anomaly> anomalies,
			String status) {
		super();
		this.testRunId = testRunId;
		this.summary = summary;
		this.performance = performance;
		this.anomalies = anomalies;
		this.status = status;
	}
	public PerformanceReport() {
		super();
		// TODO Auto-generated constructor stub
	}
    
    
}
