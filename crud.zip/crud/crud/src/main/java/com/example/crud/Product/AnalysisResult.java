package com.example.crud.Product;

import java.util.List;

import jakarta.persistence.CollectionTable;
import jakarta.persistence.Column;
import jakarta.persistence.ElementCollection;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.*;
import jakarta.persistence.Table;

@Entity
@Table(name = "analysis_results")
public class AnalysisResult {
	
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private Long testRunId;
    private int totalRequests;
    private int successRequests;
    private int failedRequests;
    private String errorRate;

    private double avgResponseTimeMs;
    private double medianResponseTimeMs;
    private double p95ResponseTimeMs;
    private long maxResponseTimeMs;
    private double throughputRps;

    @ElementCollection
    private List<String> anomalies;

    private String status;

    public AnalysisResult(Long testRunId, int totalRequests, int successRequests, int failedRequests,
            String errorRate, double avgResponseTimeMs, double medianResponseTimeMs, double p95ResponseTimeMs,
            long maxResponseTimeMs, double throughputRps, List<String> anomalies, String status) {
        this.testRunId = testRunId;
        this.totalRequests = totalRequests;
        this.successRequests = successRequests;
        this.failedRequests = failedRequests;
        this.errorRate = errorRate;
        this.avgResponseTimeMs = avgResponseTimeMs;
        this.medianResponseTimeMs = medianResponseTimeMs;
        this.p95ResponseTimeMs = p95ResponseTimeMs;
        this.maxResponseTimeMs = maxResponseTimeMs;
        this.throughputRps = throughputRps;
        this.anomalies = anomalies;
        this.status = status;
    }

	public AnalysisResult() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Long getTestRunId() {
		return testRunId;
	}

	public void setTestRunId(Long testRunId) {
		this.testRunId = testRunId;
	}

	public int getTotalRequests() {
		return totalRequests;
	}

	public void setTotalRequests(int totalRequests) {
		this.totalRequests = totalRequests;
	}

	public int getSuccessRequests() {
		return successRequests;
	}

	public void setSuccessRequests(int successRequests) {
		this.successRequests = successRequests;
	}

	public int getFailedRequests() {
		return failedRequests;
	}

	public void setFailedRequests(int failedRequests) {
		this.failedRequests = failedRequests;
	}

	public String getErrorRate() {
		return errorRate;
	}

	public void setErrorRate(String errorRate) {
		this.errorRate = errorRate;
	}

	public double getAvgResponseTimeMs() {
		return avgResponseTimeMs;
	}

	public void setAvgResponseTimeMs(double avgResponseTimeMs) {
		this.avgResponseTimeMs = avgResponseTimeMs;
	}

	public double getMedianResponseTimeMs() {
		return medianResponseTimeMs;
	}

	public void setMedianResponseTimeMs(double medianResponseTimeMs) {
		this.medianResponseTimeMs = medianResponseTimeMs;
	}

	public double getP95ResponseTimeMs() {
		return p95ResponseTimeMs;
	}

	public void setP95ResponseTimeMs(double p95ResponseTimeMs) {
		this.p95ResponseTimeMs = p95ResponseTimeMs;
	}

	public long getMaxResponseTimeMs() {
		return maxResponseTimeMs;
	}

	public void setMaxResponseTimeMs(long maxResponseTimeMs) {
		this.maxResponseTimeMs = maxResponseTimeMs;
	}

	public double getThroughputRps() {
		return throughputRps;
	}

	public void setThroughputRps(double throughputRps) {
		this.throughputRps = throughputRps;
	}

	public List<String> getAnomalies() {
		return anomalies;
	}

	public void setAnomalies(List<String> anomalies) {
		this.anomalies = anomalies;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}
    
    
		
	    
	    

}
