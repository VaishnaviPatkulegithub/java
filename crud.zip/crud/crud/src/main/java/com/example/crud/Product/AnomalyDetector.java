package com.example.crud.Product;

import java.util.ArrayList;
import java.util.List;

public class AnomalyDetector {
	
//	public static List<String> detectAnomalies(List<JMeterResult> results) {
//        List<String> anomalies = new ArrayList();
//
//        for (JMeterResult result : results) {
//            if (result.getElapsed() > 2000) { // 2 seconds threshold
//                anomalies.add("High response time at API: " 
//                              + result.getLabel() 
//                              + " (" + result.getElapsed() + " ms)");
//            }
//            if (!result.isSuccess()) {
//                anomalies.add("Failure detected at API: " + result.getLabel());
//            }
//        }
//        return anomalies;
//    }
	
	public static List<String> detectAnomalies(List<JMeterResult> results) {
		List<String> anomalies = new ArrayList<>();
		for (JMeterResult r : results) {
		if (r.getElapsed() > 2000) {
		anomalies.add("High response time for " + r.getLabel() + ": " + r.getElapsed() + " ms");
		}
		if (!r.isSuccess()) {
		anomalies.add("Failure for " + r.getLabel() + " at ts=" + r.getTimestamp());
		}
		}
		return anomalies;
		}

}
