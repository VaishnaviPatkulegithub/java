package com.example.crud.Product;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface JMeterResultRepository extends JpaRepository<JMeterResult, Long>{

}
