package com.example.crud.Product;

public class JtlRecord {
	 private long timestamp; 
	    private long elapsed;   
	    private boolean success;
		public long getTimestamp() {
			return timestamp;
		}
		public void setTimestamp(long timestamp) {
			this.timestamp = timestamp;
		}
		public long getElapsed() {
			return elapsed;
		}
		public void setElapsed(long elapsed) {
			this.elapsed = elapsed;
		}
		public boolean isSuccess() {
			return success;
		}
		public void setSuccess(boolean success) {
			this.success = success;
		}
		public JtlRecord(long timestamp, long elapsed, boolean success) {
			super();
			this.timestamp = timestamp;
			this.elapsed = elapsed;
			this.success = success;
		}
		public JtlRecord() {
			super();
			// TODO Auto-generated constructor stub
		}

	    
}
