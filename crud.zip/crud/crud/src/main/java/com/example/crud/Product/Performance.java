package com.example.crud.Product;

public class Performance {

	 private double avgResponseTimeMs;
	    private double medianResponseTimeMs;
	    private double p95ResponseTimeMs;
	    private long maxResponseTimeMs;
	    private double throughputRps;
		public double getAvgResponseTimeMs() {
			return avgResponseTimeMs;
		}
		public void setAvgResponseTimeMs(double avgResponseTimeMs) {
			this.avgResponseTimeMs = avgResponseTimeMs;
		}
		public double getMedianResponseTimeMs() {
			return medianResponseTimeMs;
		}
		public void setMedianResponseTimeMs(double medianResponseTimeMs) {
			this.medianResponseTimeMs = medianResponseTimeMs;
		}
		public double getP95ResponseTimeMs() {
			return p95ResponseTimeMs;
		}
		public void setP95ResponseTimeMs(double p95ResponseTimeMs) {
			this.p95ResponseTimeMs = p95ResponseTimeMs;
		}
		public long getMaxResponseTimeMs() {
			return maxResponseTimeMs;
		}
		public void setMaxResponseTimeMs(long maxResponseTimeMs) {
			this.maxResponseTimeMs = maxResponseTimeMs;
		}
		public double getThroughputRps() {
			return throughputRps;
		}
		public void setThroughputRps(double throughputRps) {
			this.throughputRps = throughputRps;
		}
		public Performance(double avgResponseTimeMs, double medianResponseTimeMs, double p95ResponseTimeMs,
				long maxResponseTimeMs, double throughputRps) {
			super();
			this.avgResponseTimeMs = avgResponseTimeMs;
			this.medianResponseTimeMs = medianResponseTimeMs;
			this.p95ResponseTimeMs = p95ResponseTimeMs;
			this.maxResponseTimeMs = maxResponseTimeMs;
			this.throughputRps = throughputRps;
		}
	    
	    
	    
}
