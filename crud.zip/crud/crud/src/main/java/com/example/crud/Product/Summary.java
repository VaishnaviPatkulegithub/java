package com.example.crud.Product;

public class Summary {
	
	private long totalRequests;
    private long successRequests;
    private long failedRequests;
    private String errorRate;
	public long getTotalRequests() {
		return totalRequests;
	}
	public void setTotalRequests(long totalRequests) {
		this.totalRequests = totalRequests;
	}
	public long getSuccessRequests() {
		return successRequests;
	}
	public void setSuccessRequests(long successRequests) {
		this.successRequests = successRequests;
	}
	public long getFailedRequests() {
		return failedRequests;
	}
	public void setFailedRequests(long failedRequests) {
		this.failedRequests = failedRequests;
	}
	public String getErrorRate() {
		return errorRate;
	}
	public void setErrorRate(String errorRate) {
		this.errorRate = errorRate;
	}
	public Summary(long totalRequests, long successRequests, long failedRequests, String errorRate) {
		super();
		this.totalRequests = totalRequests;
		this.successRequests = successRequests;
		this.failedRequests = failedRequests;
		this.errorRate = errorRate;
	}
	public Summary() {
		super();
		// TODO Auto-generated constructor stub
	}
    
    

}
