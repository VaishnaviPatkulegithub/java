package com.example.crud.Product;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import jakarta.websocket.server.ServerEndpoint;

@Service
public class ProductService {
	
	@Autowired
	private ProductRepository productRepo;
	
	public Product save(Product prod) {
		return productRepo.save(prod);
	}
	
	public Product getdata(Long id) {
		return productRepo.findById(id).orElse(null);
	}
	
	public List<Product> getAlldata() {
		return productRepo.findAll();
	}

}
