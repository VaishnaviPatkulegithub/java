package com.example.crud.Product;

import org.springframework.stereotype.Component;

import io.micrometer.core.instrument.MeterRegistry;

@Component
public class PerformanceMetrics {

    private final MeterRegistry registry;

    public PerformanceMetrics(MeterRegistry registry) {
        this.registry = registry;
    }

    public void recordMetrics(long totalRequests, double avgResponse, long errorCount, int anomalyCount) {
        registry.gauge("jmeter_requests_total", totalRequests);
        registry.gauge("jmeter_avg_response_time_ms", avgResponse);
        registry.gauge("jmeter_error_count", errorCount);
        registry.gauge("jmeter_anomaly_count", anomalyCount);
    }
    
    

    
}
