package com.example.crud.Product;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/Product")
public class ProductController {
	
	@Autowired
	private ProductService prodService;
	
	@PostMapping("/AddEntry")
	public Product add(@RequestBody Product prod) {
		return prodService.save(prod);
	}
	
	@GetMapping("/getProduct/{id}")
	public Product getDa(@PathVariable Long id) {
		return prodService.getdata(id);
	
	}
	
	@GetMapping("/AllProducts")
	public List<Product> getDa() {
		return prodService.getAlldata();
	
	}

}
