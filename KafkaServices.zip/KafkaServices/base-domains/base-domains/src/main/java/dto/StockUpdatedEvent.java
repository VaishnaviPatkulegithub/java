package dto;

public class StockUpdatedEvent {
	
	 private String productId;
	    private int remainingStock;
	    
		public String getProductId() {
			return productId;
		}
		public void setProductId(String productId) {
			this.productId = productId;
		}
		public int getRemainingStock() {
			return remainingStock;
		}
		public void setRemainingStock(int remainingStock) {
			this.remainingStock = remainingStock;
		}
		public StockUpdatedEvent() {
			super();
			// TODO Auto-generated constructor stub
		}
		public StockUpdatedEvent(String productId, int remainingStock) {
			super();
			this.productId = productId;
			this.remainingStock = remainingStock;
		}
	    
		
	    

}
