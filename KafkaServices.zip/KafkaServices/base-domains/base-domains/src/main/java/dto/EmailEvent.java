package dto;

public class EmailEvent {
	
	 private String orderId;
	    private String email;
	    private String message;
		public String getOrderId() {
			return orderId;
		}
		public void setOrderId(String orderId) {
			this.orderId = orderId;
		}
		public String getEmail() {
			return email;
		}
		public void setEmail(String email) {
			this.email = email;
		}
		public String getMessage() {
			return message;
		}
		public void setMessage(String message) {
			this.message = message;
		}
		public EmailEvent(String orderId, String email, String message) {
			super();
			this.orderId = orderId;
			this.email = email;
			this.message = message;
		}
		public EmailEvent() {
			super();
			// TODO Auto-generated constructor stub
		}
	    
	    

}
