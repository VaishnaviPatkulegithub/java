package Controller;

import java.util.UUID;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import Kafka.OrderProducer;
import dto.Order;
import dto.OrderEvent;

@RestController
@RequestMapping("/orders")
public class OrderController {

	private final OrderProducer producer;

    public OrderController(OrderProducer producer) {
        this.producer = producer;
    }

@GetMapping
public String createOrder() {
        return "order created.....";
    }
}
