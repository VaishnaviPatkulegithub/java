package consumer;

import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;

import dto.OrderEvent;
import dto.StockUpdatedEvent;
import dto.OrderEvent;

@Service

public class OrderConsumer {

	 private final KafkaTemplate<String, Object> kafkaTemplate;

	    public OrderConsumer(KafkaTemplate<String, Object> kafkaTemplate) {
	        this.kafkaTemplate = kafkaTemplate;
	    }

	    @KafkaListener(topics = "order-topic", groupId = "stock-service")
	    public void consume(OrderEvent event) {
	        System.out.println("📥 Received Order: " + event);

	        int remainingStock = 100 - event.getQuantity(); // dummy logic
	        StockUpdatedEvent stockEvent = new StockUpdatedEvent(event.getProductId(), remainingStock);

	        kafkaTemplate.send("stock-topic", stockEvent);
	        System.out.println("📤 Published StockUpdatedEvent: " + stockEvent);
	    }
}
