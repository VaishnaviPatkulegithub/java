package Producer;

import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Service;

import dto.StockUpdatedEvent;


@Service
public class StockProducer {

	 @KafkaListener(topics = "stock-topic", groupId = "email-service")
	    public void consume(StockUpdatedEvent event) {
	        System.out.println("📩 Sending email: Product " + event.getProductId()
	                + " now has " + event.getRemainingStock() + " left in stock.");
	    }
}
