package com.example.anomalies.anomalies.anomaly;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface AnomalyRepository extends JpaRepository<Anomaly, Long>{

	 List<Anomaly> findByTestRunId(Long testRunId);
}
