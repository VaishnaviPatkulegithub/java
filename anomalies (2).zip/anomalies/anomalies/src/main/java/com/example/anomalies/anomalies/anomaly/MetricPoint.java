package com.example.anomalies.anomalies.anomaly;

import java.time.Instant;

import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity

@Builder
@NoArgsConstructor
@AllArgsConstructor
public class MetricPoint {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;


	@ManyToOne
	@JoinColumn(name = "test_run_id")
	private TestRun testRun;


	private String metricName; 
	private Double value;
	private Instant timestamp;

	private String tags;


	public Long getId() {
		return id;
	}


	public void setId(Long id) {
		this.id = id;
	}


	public TestRun getTestRun() {
		return testRun;
	}


	public void setTestRun(TestRun testRun) {
		this.testRun = testRun;
	}


	public String getMetricName() {
		return metricName;
	}


	public void setMetricName(String metricName) {
		this.metricName = metricName;
	}


	public Double getValue() {
		return value;
	}


	public void setValue(Double value) {
		this.value = value;
	}


	public Instant getTimestamp() {
		return timestamp;
	}


	public void setTimestamp(Instant timestamp) {
		this.timestamp = timestamp;
	}


	public String getTags() {
		return tags;
	}


	public void setTags(String tags) {
		this.tags = tags;
	}


	public MetricPoint(Long id, TestRun testRun, String metricName, Double value, Instant timestamp, String tags) {
		super();
		this.id = id;
		this.testRun = testRun;
		this.metricName = metricName;
		this.value = value;
		this.timestamp = timestamp;
		this.tags = tags;
	}


	public MetricPoint() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
	

}
