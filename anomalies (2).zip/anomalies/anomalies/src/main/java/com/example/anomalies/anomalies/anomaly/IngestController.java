package com.example.anomalies.anomalies.anomaly;

import java.io.IOException;
import java.util.Map;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

@RestController
@RequestMapping("/api/ingest")
public class IngestController {

	private final IngestService ingestService;


	public IngestController(IngestService ingestService) {
	this.ingestService = ingestService;
	}

	
	@PostMapping(value = "/tests", consumes = "multipart/form-data")
	public ResponseEntity<?> uploadTestRun(@RequestParam("file") MultipartFile file,
	@RequestParam(value = "source", required = false, defaultValue = "jmeter") String source,
	@RequestParam(value = "name", required = false) String name) throws Exception {
	var id = ingestService.processTestRunFile(file, source, name);
	return ResponseEntity.ok().body(Map.of("testRunId", id));
	}


	
	@PostMapping("/prometheus")
	public ResponseEntity<?> pushPrometheusMetrics(@RequestBody String promText,
	@RequestParam(value = "name", required = false) String name) throws IOException {
	var id = ingestService.processPrometheusText(promText, name);
	return ResponseEntity.ok().body(Map.of("testRunId", id));
	}
}
