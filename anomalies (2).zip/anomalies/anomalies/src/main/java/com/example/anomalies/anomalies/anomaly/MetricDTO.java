package com.example.anomalies.anomalies.anomaly;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class MetricDTO {
	
	 private String metricName;
	    private Double value;
	    private Long timestamp;
		public String getMetricName() {
			return metricName;
		}
		public void setMetricName(String metricName) {
			this.metricName = metricName;
		}
		public Double getValue() {
			return value;
		}
		public void setValue(Double value) {
			this.value = value;
		}
		public Long getTimestamp() {
			return timestamp;
		}
		public void setTimestamp(Long timestamp) {
			this.timestamp = timestamp;
		}
	    
	    

}
