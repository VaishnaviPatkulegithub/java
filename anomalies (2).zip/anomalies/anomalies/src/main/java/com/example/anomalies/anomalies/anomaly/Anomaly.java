package com.example.anomalies.anomalies.anomaly;

import java.time.Instant;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Anomaly {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;


	private Long testRunId;
	private String metricName;
	private Double value;
	private String type; 
	private String details; 
	private Instant detectedAt;
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public Long getTestRunId() {
		return testRunId;
	}
	public void setTestRunId(Long testRunId) {
		this.testRunId = testRunId;
	}
	public String getMetricName() {
		return metricName;
	}
	public void setMetricName(String metricName) {
		this.metricName = metricName;
	}
	public Double getValue() {
		return value;
	}
	public void setValue(Double value) {
		this.value = value;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getDetails() {
		return details;
	}
	public void setDetails(String details) {
		this.details = details;
	}
	public Instant getDetectedAt() {
		return detectedAt;
	}
	public void setDetectedAt(Instant detectedAt) {
		this.detectedAt = detectedAt;
	}
	public Anomaly(Long id, Long testRunId, String metricName, Double value, String type, String details,
			Instant detectedAt) {
		super();
		this.id = id;
		this.testRunId = testRunId;
		this.metricName = metricName;
		this.value = value;
		this.type = type;
		this.details = details;
		this.detectedAt = detectedAt;
	}
	public Anomaly() {
		super();
	}
	
	
	
	
}
