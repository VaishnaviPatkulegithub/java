package com.example.anomalies.anomalies.anomaly;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.time.Instant;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class IngestService {
	
	private final TestRunRepository testRunRepo;
	private final MetricPointRepository metricRepo;
	private final AnomalyRepository anomalyRepo;
	private final AnomalyClient anomalyClient;
	
	public IngestService(TestRunRepository testRunRepo,
			MetricPointRepository metricRepo,
			AnomalyRepository anomalyRepo,
			AnomalyClient anomalyClient) {
			this.testRunRepo = testRunRepo;
			this.metricRepo = metricRepo;
			this.anomalyRepo = anomalyRepo;
			this.anomalyClient = anomalyClient;
			}
	
	public Long processTestRunFile(MultipartFile file, String source, String name) throws Exception {
	
		List<MetricPoint> points = parseFileToMetricPoints(file, source);


	
		TestRun run = new TestRun();
		run.setName(name == null ? file.getOriginalFilename() : name);
		run.setSource(source);
		run.setStartedAt(points.stream().map(MetricPoint::getTimestamp).min(Comparator.naturalOrder()).orElse(Instant.now()));
		run.setFinishedAt(points.stream().map(MetricPoint::getTimestamp).max(Comparator.naturalOrder()).orElse(Instant.now()));
		run = testRunRepo.save(run);


		for (MetricPoint mp : points) {
		mp.setTestRun(run);
		}
		metricRepo.saveAll(points);


	
		List<Anomaly> anomalies = anomalyClient.findAnomaliesForSeries(run.getId(), points);
		anomalyRepo.saveAll(anomalies);


		return run.getId();
		}
	
	public Long processPrometheusText(String promText, String name) throws IOException {
		List<MetricPoint> points = PrometheusParser.parse(promText);


		TestRun run = new TestRun();
		run.setName(name == null ? "PrometheusRun" : name);
		run.setSource("prometheus");
		run.setStartedAt(Instant.now());
		run.setFinishedAt(Instant.now());
		run = testRunRepo.save(run);


		for (MetricPoint mp : points) {
		mp.setTestRun(run);
		}
		metricRepo.saveAll(points);


		List<Anomaly> anomalies = anomalyClient.findAnomaliesForSeries(run.getId(), points);
		anomalyRepo.saveAll(anomalies);


		return run.getId();
		}


		private List<MetricPoint> parseFileToMetricPoints(MultipartFile file, String source) throws IOException {
		
		List<MetricPoint> points = new ArrayList<>();
		try (BufferedReader reader = new BufferedReader(new InputStreamReader(file.getInputStream()))) {
		String line;
		long ts = System.currentTimeMillis();
		while ((line = reader.readLine()) != null) {
		if (line.trim().isEmpty()) continue;
		MetricPoint mp = new MetricPoint();
		mp.setMetricName("latency_ms");
		mp.setValue(Double.parseDouble(line.replaceAll("[^0-9]", ""))); // simplistic parse
		mp.setTimestamp(Instant.ofEpochMilli(ts));
		points.add(mp);
		ts += 1000;
		}
		}
		return points;
		}
	
}
	
