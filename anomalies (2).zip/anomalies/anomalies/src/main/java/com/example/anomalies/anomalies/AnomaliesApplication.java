package com.example.anomalies.anomalies;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AnomaliesApplication {

	public static void main(String[] args) {
		SpringApplication.run(AnomaliesApplication.class, args);
	}

}
