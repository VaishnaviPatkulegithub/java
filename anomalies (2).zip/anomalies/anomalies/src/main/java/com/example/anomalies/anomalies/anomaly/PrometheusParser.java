package com.example.anomalies.anomalies.anomaly;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.StringReader;
import java.time.Instant;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class PrometheusParser {

	 private static final Pattern PROM_PATTERN =
	            Pattern.compile("^(\\w+)(\\{[^}]*})?\\s+([0-9.eE+-]+)(?:\\s+(\\d+))?$");

	    public static List<MetricPoint> parse(String content) throws IOException {
	        List<MetricPoint> points = new ArrayList(null);
	        try (BufferedReader reader = new BufferedReader(new StringReader(content))) {
	            String line;
	            while ((line = reader.readLine()) != null) {
	                line = line.trim();
	                if (line.isEmpty() || line.startsWith("#")) {
	                    continue; // skip comments/headers
	                }
	                Matcher matcher = PROM_PATTERN.matcher(line);
	                if (matcher.matches()) {
	                    String name = matcher.group(1);
	                    String labels = matcher.group(2);
	                    double value = Double.parseDouble(matcher.group(3));
	                    String tsStr = matcher.group(4);

	                    Instant ts = (tsStr != null)
	                            ? Instant.ofEpochMilli(Long.parseLong(tsStr))
	                            : Instant.now();

	                    MetricPoint mp = new MetricPoint();
	                    mp.setMetricName(name + (labels != null ? labels : ""));
	                    mp.setValue(value);
	                    mp.setTimestamp(ts);
	                    points.add(mp);
	                }
	            }
	        }
	        return points;
	    }
}
