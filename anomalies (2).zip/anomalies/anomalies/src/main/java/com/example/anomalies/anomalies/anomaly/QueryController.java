package com.example.anomalies.anomalies.anomaly;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api")
public class QueryController {

	private final QueryService queryService;
	public QueryController(QueryService queryService) { this.queryService = queryService; }


	@GetMapping("/results/{id}")
	public ResponseEntity<?> getResults(@PathVariable Long id) {
	return ResponseEntity.ok(queryService.getTestRunWithMetrics(id));
	}


	@GetMapping("/anomalies")
	public ResponseEntity<?> getAnomalies(@RequestParam(required = false) Long testRunId) {
	return ResponseEntity.ok(queryService.findAnomalies(testRunId));
	}
	
}
