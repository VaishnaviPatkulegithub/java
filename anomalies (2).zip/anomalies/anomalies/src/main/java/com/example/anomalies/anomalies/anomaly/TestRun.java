package com.example.anomalies.anomalies.anomaly;

import java.time.Instant;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnore;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity

@Builder
@NoArgsConstructor
@AllArgsConstructor
public class TestRun {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;


	private String name; 
	private String source; 
	private Instant startedAt;
	private Instant finishedAt;


	@OneToMany(mappedBy = "testRun", fetch = FetchType.LAZY)
	 @JsonIgnore
	private List<MetricPoint> points;


	public Long getId() {
		return id;
	}


	public void setId(Long id) {
		this.id = id;
	}


	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	public String getSource() {
		return source;
	}


	public void setSource(String source) {
		this.source = source;
	}


	public Instant getStartedAt() {
		return startedAt;
	}


	public void setStartedAt(Instant startedAt) {
		this.startedAt = startedAt;
	}


	public Instant getFinishedAt() {
		return finishedAt;
	}


	public void setFinishedAt(Instant finishedAt) {
		this.finishedAt = finishedAt;
	}


	public List<MetricPoint> getPoints() {
		return points;
	}


	public void setPoints(List<MetricPoint> points) {
		this.points = points;
	}


	public TestRun(Long id, String name, String source, Instant startedAt, Instant finishedAt,
			List<MetricPoint> points) {
		super();
		this.id = id;
		this.name = name;
		this.source = source;
		this.startedAt = startedAt;
		this.finishedAt = finishedAt;
		this.points = points;
	}


	public TestRun() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	

	
    
    

}
