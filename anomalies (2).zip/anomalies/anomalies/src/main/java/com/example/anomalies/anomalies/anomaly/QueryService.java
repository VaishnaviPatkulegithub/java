package com.example.anomalies.anomalies.anomaly;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;



@Service
public class QueryService {
	
	private final TestRunRepository testRunRepo;
	private final MetricPointRepository metricRepo;
	private final AnomalyRepository anomalyRepo;
	private final AnomalyClient anomalyClient;


	public QueryService(TestRunRepository testRunRepo,
	MetricPointRepository metricRepo,
	AnomalyRepository anomalyRepo,
	AnomalyClient anomalyClient) {
	this.testRunRepo = testRunRepo;
	this.metricRepo = metricRepo;
	this.anomalyRepo = anomalyRepo;
	this.anomalyClient = anomalyClient;
	}

	   public Map<String, Object> getTestRunWithMetrics(Long id) {
	        Optional<TestRun> runOpt = testRunRepo.findById(id);
	        if (runOpt.isEmpty()) {
	            return Map.of("error", "Test run not found");
	        }

	        TestRun run = runOpt.get();
	        List<MetricPoint> points = metricRepo.findByTestRunId(id);

	        return Map.of(
	                "testRun", run,
	                "metrics", points
	        );
	    }

	    public Map<String, Object> getTestRunWithMetricsAndAnomalies(Long id) {
	        Optional<TestRun> runOpt = testRunRepo.findById(id);
	        if (runOpt.isEmpty()) {
	            return Map.of("error", "Test run not found");
	        }

	        TestRun run = runOpt.get();
	        List<MetricPoint> points = metricRepo.findByTestRunId(id);

	        Map<String, Object> result = anomalyClient.detectAnomalies(points);

	        Map<String, Object> response = new HashMap();
	        response.put("testRunId", id);
	        response.put("metrics", points);
	        response.put("anomalies", result);
			return response;
	    }

	    
	public List<Anomaly> findAnomalies(Long testRunId) {
	if (testRunId == null) return anomalyRepo.findAll();
	return anomalyRepo.findByTestRunId(testRunId);
	}

}
