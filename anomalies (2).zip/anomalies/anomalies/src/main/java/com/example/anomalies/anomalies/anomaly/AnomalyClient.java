package com.example.anomalies.anomalies.anomaly;

import java.time.Instant;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.client.WebClient;

@Component
public class AnomalyClient {

	private final WebClient webClient;


	public AnomalyClient(WebClient.Builder builder, @Value("${anomaly.service.url}") String baseUrl) {
	this.webClient = builder.baseUrl(baseUrl).build();
	}


	public List<Anomaly> findAnomaliesForSeries(Long testRunId, List<MetricPoint> points) {
	Map<String, Object> payload = Map.of(
	"testRunId", testRunId,
	"series", points.stream().map(p -> Map.of(
	"metric", p.getMetricName(),
	"value", p.getValue(),
	"ts", p.getTimestamp().toEpochMilli()
	)).collect(Collectors.toList())
	);


	List<Map<String, Object>> response = webClient.post()
	.uri("/detect")
	.bodyValue(payload)
	.retrieve()
	.bodyToMono(List.class)
	.block();


	if (response == null) return List.of();


	List<Anomaly> anomalies = new ArrayList();
	for (Map<String, Object> r : response) {
	Anomaly a = new Anomaly();
	a.setTestRunId(testRunId);
	a.setMetricName((String) r.get("metric"));
	a.setValue(Double.valueOf(r.get("value").toString()));
	a.setType((String) r.get("type"));
	a.setDetails(r.toString());
	a.setDetectedAt(Instant.now());
	anomalies.add(a);
	}
	return anomalies;
	}
	
	public Map<String, Object> detectAnomalies(List<MetricPoint> metrics) {
	    Map<String, Object> response = new HashMap();
	    response.put("status", "success");
	    response.put("anomalies", List.of()); 
	    return response;
	}
}
