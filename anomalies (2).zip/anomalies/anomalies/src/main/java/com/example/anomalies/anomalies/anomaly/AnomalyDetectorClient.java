package com.example.anomalies.anomalies.anomaly;

import org.springframework.http.*;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.reactive.function.client.WebClient;

import reactor.core.publisher.Mono;


@Component
public class AnomalyDetectorClient {
	
	private final WebClient webclient = WebClient.builder().build();
//	  private final RestTemplate restTemplate;
//	  private final String anomalyServiceUrl;
//	
//	@Value("${anomaly.service.url}")
//    private String anomalyServiceUrl;
	
    private final RestTemplate restTemplate;
    private final String anomalyServiceUrl;

    public AnomalyDetectorClient(RestTemplate restTemplate,
                         @Value("${anomaly.service.url:http://localhost:5000/analyze}") String anomalyServiceUrl) {
        this.restTemplate = restTemplate;
        this.anomalyServiceUrl = anomalyServiceUrl;
    }
	

	
//	public List<Map<String, Object>> detectAnomalies(List<MetricDTO> metries){
//		
//		Mono<List> response = webclient.post().uri(anomalyServiceUrl).bodyValue(Map.of("metrics", metries)).retrieve().bodyToMono(List.class);
//		
//		return response.block();
//		
//	}
	
//    @SuppressWarnings("unchecked")
//    public Map<String, Object> detectAnomalies(List<Map<String, Object>> points) {
//        HttpHeaders headers = new HttpHeaders();
//        headers.setContentType(MediaType.APPLICATION_JSON);
//
//        HttpEntity<List<Map<String, Object>>> entity = new HttpEntity<>(points, headers);
//
//        ResponseEntity<Map> response =
//                restTemplate.exchange(anomalyServiceUrl, HttpMethod.POST, entity, Map.class);
//
//        if (response.getStatusCode().is2xxSuccessful()) {
//            return response.getBody();
//        } else {
//            return Map.of("error", "Failed to call anomaly service, status: " + response.getStatusCode());
//        }
//    }

    @SuppressWarnings("unchecked")
    public Map<String, Object> detectAnomalies(List<? extends Map<String, ?>> points) {
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);

        HttpEntity<List<? extends Map<String, ?>>> entity = new HttpEntity<>(points, headers);

        ResponseEntity<Map> response =
                restTemplate.exchange(anomalyServiceUrl, HttpMethod.POST, entity, Map.class);

        if (response.getStatusCode().is2xxSuccessful()) {
            return response.getBody();
        } else {
            return Map.of("error", "Failed to call anomaly service, status: " + response.getStatusCode());
        }
    }
    
}
