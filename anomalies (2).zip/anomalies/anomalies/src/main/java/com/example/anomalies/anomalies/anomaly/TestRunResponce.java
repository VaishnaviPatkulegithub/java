package com.example.anomalies.anomalies.anomaly;

import java.util.List;

public class TestRunResponce {
	
	 private TestRun testRun;
	    private List<MetricPoint> metrics;
	    
	    
		public TestRunResponce(TestRun testRun, List<MetricPoint> metrics) {
			super();
			this.testRun = testRun;
			this.metrics = metrics;
		}


		public TestRun getTestRun() {
			return testRun;
		}


		public void setTestRun(TestRun testRun) {
			this.testRun = testRun;
		}


		public List<MetricPoint> getMetrics() {
			return metrics;
		}


		public void setMetrics(List<MetricPoint> metrics) {
			this.metrics = metrics;
		}

		
	
}
