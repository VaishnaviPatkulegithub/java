package com.example.anomalies.anomalies.anomaly;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface MetricPointRepository extends JpaRepository<MetricPoint, Long>{

	List<MetricPoint> findByTestRunId(Long testRunId);
}
