package com.example.Producer;

import org.springframework.http.ResponseEntity;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api")
public class MessageController {

	  private final KafkaTemplate<String, String> kafkaTemplate;

	    public MessageController(KafkaTemplate<String, String> kafkaTemplate) {
	        this.kafkaTemplate = kafkaTemplate;
	    }

	    @PostMapping("/messages")
	    public ResponseEntity<String> sendMessage(@RequestParam String message) {
	        kafkaTemplate.send("test-topic", message);
	        return ResponseEntity.ok("Message sent to Kafka: " + message);
	    }
}
